Hall Effect Keypad Firmware

This firmware supports per-key calibration, rapid trigger, per-key RGB, and a menu system using an SSD1306 OLED and rotary encoder.