// Settings and menu system header
#ifndef SETTINGS_H
#define SETTINGS_H
// Menu system code here
#endif